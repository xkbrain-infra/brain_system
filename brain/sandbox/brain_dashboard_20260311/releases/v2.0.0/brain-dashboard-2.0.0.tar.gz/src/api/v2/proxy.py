"""Proxy Stats API - T1 Implementation.

Provides endpoints to query traffic statistics from brain_gateway.
"""

import time
import httpx
from typing import Any
from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/proxy", tags=["proxy"])

# brain_gateway endpoint
GATEWAY_STATS_URL = "http://127.0.0.1:8200/stats"


@router.get("/stats")
async def get_proxy_stats() -> dict[str, Any]:
    """Get proxy traffic statistics from brain_gateway.

    Returns:
        JSON with QPS, latency, error rate, and traffic metrics.
    """
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(GATEWAY_STATS_URL)
            response.raise_for_status()
            stats_data = response.json()
    except httpx.ConnectError as e:
        raise HTTPException(
            status_code=503,
            detail=f"Failed to connect to brain_gateway: {e}"
        )
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=504,
            detail="Timeout waiting for brain_gateway response"
        )
    except httpx.HTTPStatusError as e:
        raise HTTPException(
            status_code=502,
            detail=f"brain_gateway returned error: {e.response.status_code}"
        )

    # Transform gateway stats to dashboard format
    # Expected gateway format: {"requests_total": N, "requests_per_sec": F,
    #                           "avg_latency_ms": F, "error_rate": F, ...}
    transformed = {
        "timestamp": int(time.time()),
        "qps": stats_data.get("requests_per_sec", 0.0),
        "total_requests": stats_data.get("requests_total", 0),
        "avg_latency_ms": stats_data.get("avg_latency_ms", 0.0),
        "p50_latency_ms": stats_data.get("p50_latency_ms", 0.0),
        "p95_latency_ms": stats_data.get("p95_latency_ms", 0.0),
        "p99_latency_ms": stats_data.get("p99_latency_ms", 0.0),
        "error_rate": stats_data.get("error_rate", 0.0),
        "errors_total": stats_data.get("errors_total", 0),
        "active_connections": stats_data.get("active_connections", 0),
        "source": "brain_gateway",
    }

    return transformed


@router.get("/routes")
async def get_proxy_routes() -> dict[str, Any]:
    """Get configured routing rules from brain_gateway.

    Returns:
        JSON with routing configuration.
    """
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get("http://127.0.0.1:8200/routes")
            response.raise_for_status()
            routes_data = response.json()
    except httpx.ConnectError as e:
        raise HTTPException(
            status_code=503,
            detail=f"Failed to connect to brain_gateway: {e}"
        )
    except httpx.HTTPStatusError:
        # Fallback to static config if endpoint not available
        routes_data = {
            "platforms": {"telegram": "agent-brain_frontdesk"},
            "keywords": [{"pattern": "(?i)(deploy|release)", "target": "agent-system_devops"}],
            "default": "agent-brain_frontdesk",
        }

    return {
        "timestamp": int(time.time()),
        "routes": routes_data,
        "source": "brain_gateway",
    }


@router.get("/traffic")
async def get_traffic_summary(minutes: int = 5) -> dict[str, Any]:
    """Get traffic summary for the last N minutes.

    Args:
        minutes: Time window in minutes (default 5).

    Returns:
        JSON with traffic summary.
    """
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(
                f"http://127.0.0.1:8200/traffic?window={minutes}m"
            )
            response.raise_for_status()
            traffic_data = response.json()
    except httpx.ConnectError as e:
        raise HTTPException(
            status_code=503,
            detail=f"Failed to connect to brain_gateway: {e}"
        )

    return {
        "timestamp": int(time.time()),
        "window_minutes": minutes,
        "requests": traffic_data.get("requests", 0),
        "errors": traffic_data.get("errors", 0),
        "error_rate": traffic_data.get("error_rate", 0.0),
        "source": "brain_gateway",
    }
